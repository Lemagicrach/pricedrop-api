"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = handler;
var _supabase = require("../../lib/supabase");
var _rapidapi = require("../../lib/rapidapi");
async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-RapidAPI-Key, X-RapidAPI-Host');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  const {
    id
  } = req.query;
  try {
    const rapidApiKey = (0, _rapidapi.verifyRapidAPI)(req);
    await (0, _rapidapi.checkRateLimit)(rapidApiKey);
    if (req.method === 'GET') {
      // Get product details with price history
      const {
        data: product,
        error
      } = await _supabase.supabase.from('products').select(`
          *,
          price_history (
            price,
            in_stock,
            created_at
          )
        `).eq('id', id).eq('rapidapi_key', rapidApiKey).single();
      if (error || !product) {
        return res.status(404).json({
          error: 'Product not found'
        });
      }
      res.status(200).json({
        success: true,
        product
      });
    } else if (req.method === 'DELETE') {
      // Delete product
      const {
        error
      } = await _supabase.supabase.from('products').delete().eq('id', id).eq('rapidapi_key', rapidApiKey);
      if (error) throw error;
      res.status(200).json({
        success: true,
        message: 'Product deleted successfully'
      });
    } else {
      res.status(405).json({
        error: 'Method not allowed'
      });
    }
  } catch (error) {
    console.error('Product operation error:', error);
    res.status(500).json({
      error: 'Operation failed',
      message: error.message
    });
  }
}
//# sourceMappingURL=[id].js.map