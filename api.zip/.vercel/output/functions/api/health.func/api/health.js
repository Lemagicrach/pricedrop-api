"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = handler;
async function handler(req, res) {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    service: 'PriceDrop API'
  });
}
//# sourceMappingURL=health.js.map