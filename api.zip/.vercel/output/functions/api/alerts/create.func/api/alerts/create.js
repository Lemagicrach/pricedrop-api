"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = handler;
var _supabase = require("../../lib/supabase");
var _rapidapi = require("../../lib/rapidapi");
var _validators = require("../../lib/validators");
async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-RapidAPI-Key, X-RapidAPI-Host, Authorization');
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  if (req.method !== 'POST') {
    return res.status(405).json({
      error: 'Method not allowed'
    });
  }

  // 🔒 Cron authorization check
  if (req.headers.authorization !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({
      error: 'Unauthorized'
    });
  }
  try {
    const rapidApiKey = (0, _rapidapi.verifyRapidAPI)(req);
    await (0, _rapidapi.checkRateLimit)(rapidApiKey);

    // Validate input
    const validatedData = _validators.createAlertSchema.parse(req.body);
    const {
      product_id,
      target_price,
      alert_type,
      notification_channels
    } = validatedData;

    // Verify product belongs to user
    const {
      data: product
    } = await _supabase.supabase.from('products').select('*').eq('id', product_id).eq('rapidapi_key', rapidApiKey).single();
    if (!product) {
      return res.status(404).json({
        error: 'Product not found'
      });
    }

    // Check for existing alert
    const {
      data: existing
    } = await _supabase.supabase.from('alerts').select('*').eq('product_id', product_id).eq('rapidapi_key', rapidApiKey).eq('is_active', true).single();
    if (existing) {
      // Update existing alert
      const {
        data: alert,
        error
      } = await _supabase.supabase.from('alerts').update({
        target_price,
        alert_type,
        notification_channels,
        updated_at: new Date().toISOString()
      }).eq('id', existing.id).select().single();
      if (error) throw error;
      return res.status(200).json({
        success: true,
        message: 'Alert updated',
        alert
      });
    }

    // Create new alert
    const {
      data: alert,
      error
    } = await _supabase.supabase.from('alerts').insert({
      product_id,
      target_price,
      alert_type,
      notification_channels,
      rapidapi_key: rapidApiKey,
      is_active: true
    }).select().single();
    if (error) throw error;
    res.status(201).json({
      success: true,
      alert
    });
  } catch (error) {
    console.error('Alert creation error:', error);
    if (error.name === 'ZodError') {
      return res.status(400).json({
        error: 'Validation error',
        details: error.errors
      });
    }
    res.status(500).json({
      error: 'Failed to create alert',
      message: error.message
    });
  }
}
//# sourceMappingURL=create.js.map