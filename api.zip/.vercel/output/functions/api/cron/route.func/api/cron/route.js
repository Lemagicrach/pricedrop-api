"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.GET = GET;
var _server = require("next/server");
async function GET() {
  return _server.NextResponse.json({
    ok: true
  });
}
//# sourceMappingURL=route.js.map